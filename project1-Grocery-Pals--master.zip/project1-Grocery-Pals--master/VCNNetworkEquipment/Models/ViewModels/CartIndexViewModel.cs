﻿using VCNNetworkEquipment.Models;

namespace VCNNetworkEquipment.Models.ViewModels
{
	public class CartIndexViewModel
	{
		public Cart Cart { get; set; }
		public string ReturnUrl { get; set; }
	}
}
